/** @type {import('next').NextConfig} */
const nextConfig = {
  outputFileTracingRoot: undefined,
  reactStrictMode: true,
};
export default nextConfig;
